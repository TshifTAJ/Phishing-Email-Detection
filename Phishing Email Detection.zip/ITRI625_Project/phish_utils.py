"""Shared helpers: prediction + simple explainability (word-occlusion XAI)."""
import re
import numpy as np


def predict_proba(model, vec, text):
    """Probability (0-1) that the email is phishing."""
    return float(model.predict_proba(vec.transform([text]))[0, 1])


def _logit(p):
    p = np.clip(p, 1e-6, 1 - 1e-6)
    return np.log(p / (1 - p))


def explain(model, vec, text, top_k=5, max_words=40):
    """Occlusion XAI: remove each important word and see how the phishing
    log-odds change. Positive score = word pushes towards PHISHING,
    negative = word pushes towards SAFE."""
    X = vec.transform([text])
    base = float(model.predict_proba(X)[0, 1])
    if X.nnz == 0:
        return base, []
    feats = vec.get_feature_names_out()
    row = X.tocoo()
    order = np.argsort(-row.data)[:max_words]          # highest TF-IDF words
    words = [feats[row.col[i]] for i in order]
    variants = [re.sub(r"\b" + re.escape(w) + r"\b", " ", text, flags=re.I) for w in words]
    probs = model.predict_proba(vec.transform(variants))[:, 1]
    scores = [(w, float(_logit(base) - _logit(p))) for w, p in zip(words, probs)]
    scores.sort(key=lambda t: abs(t[1]), reverse=True)
    return base, scores[:top_k]
