"""Tkinter desktop app. Start api.py first, then run:  python app.py"""
import tkinter as tk
from tkinter import messagebox
import requests

API_URL = "http://127.0.0.1:5000/predict"


def check():
    text = box.get("1.0", tk.END).strip()
    if not text:
        messagebox.showwarning("Empty", "Paste an email first.")
        return
    try:
        r = requests.post(API_URL, json={"text": text}, timeout=10)
        r.raise_for_status()
        d = r.json()
    except Exception as e:
        messagebox.showerror("API error", f"Is api.py running?\n\n{e}")
        return
    phishing = d["label"] == "Phishing"
    result.config(text=f"{d['label'].upper()}  ({d['phishing_probability']*100:.1f}% phishing)",
                  fg="red" if phishing else "green")
    lines = [f"{'↑ phishing' if w['impact'] > 0 else '↓ safe':<11} {w['word']}  ({w['impact']:+.3f})"
             for w in d["top_words"]]
    why.config(text="Why? Top influencing words:\n" + "\n".join(lines))


root = tk.Tk()
root.title("Phishing Email Detector")
root.geometry("640x520")
tk.Label(root, text="Paste email text below:", font=("Arial", 12)).pack(pady=5)
box = tk.Text(root, height=15, wrap="word")
box.pack(padx=10, fill="both", expand=True)
tk.Button(root, text="Check Email", font=("Arial", 12, "bold"), command=check).pack(pady=8)
result = tk.Label(root, text="", font=("Arial", 16, "bold"))
result.pack()
why = tk.Label(root, text="", font=("Courier", 10), justify="left")
why.pack(pady=5)
root.mainloop()
