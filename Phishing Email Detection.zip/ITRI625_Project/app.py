"""Desktop launcher: starts the API if needed and opens the web interface in its own window.
Run:  python app.py      (the old Tkinter window is still available as app_tkinter.py)"""
import os, shutil, subprocess, sys, threading, time, webbrowser
import requests

URL = "http://127.0.0.1:5000"


def running():
    try:
        return requests.get(URL + "/health", timeout=1).ok
    except requests.RequestException:
        return False


def start_api():
    from api import app
    threading.Thread(target=lambda: app.run(port=5000, use_reloader=False), daemon=True).start()
    for _ in range(50):
        if running():
            return
        time.sleep(0.2)
    sys.exit("The model did not start. Run python api.py to see the error.")


def find_browser():
    names = ["msedge", "chrome", "google-chrome", "chromium", "chromium-browser"]
    for n in names:
        p = shutil.which(n)
        if p:
            return p
    for base in filter(None, [os.environ.get("ProgramFiles(x86)"), os.environ.get("ProgramFiles"), os.environ.get("LOCALAPPDATA")]):
        for rel in [r"Microsoft\Edge\Application\msedge.exe", r"Google\Chrome\Application\chrome.exe"]:
            p = os.path.join(base, rel)
            if os.path.exists(p):
                return p
    return None


if __name__ == "__main__":
    started = not running()
    if started:
        start_api()
    b = find_browser()
    if b:
        proc = subprocess.Popen([b, f"--app={URL}", "--window-size=1180,820"])
        if started:
            proc.wait()  # closing the window stops everything
    else:
        webbrowser.open(URL)
        if started:
            print("Running at", URL, "- press Ctrl+C to stop.")
            try:
                while True:
                    time.sleep(1)
            except KeyboardInterrupt:
                pass
