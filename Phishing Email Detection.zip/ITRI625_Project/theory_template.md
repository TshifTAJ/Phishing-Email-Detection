# ITRI625 Project – Theory Component
**Project:** Phishing Email Detection using TF-IDF and a Neural Network (MLP)

## 3.1 Model scenario (3 marks)
Phishing emails trick users into revealing passwords, banking details or installing malware, and remain one of the most common entry points for cyber-attacks. Manually checking every email is impossible for an organisation. This model reads the text of an email and classifies it as **Phishing** or **Safe**, so that suspicious messages can be flagged or quarantined before a user acts on them. It is deployed as a small Flask API used by a desktop application (a Tkinter window, and a web-style window that opens from `app.py`), where a user pastes an email and instantly receives a verdict, a confidence score and the words that influenced the decision (explainable AI).

## 3.2 Model architecture (10 marks)
**Pipeline:** Raw email text → TF-IDF vectoriser → Multi-Layer Perceptron (MLP) → phishing probability.

![Figure 1: Model architecture](figures/05_architecture.png)

**Pre-processing (TF-IDF).** Text is lower-cased, English stop-words are removed and each email is converted into a vector of <<N_FEATURES>> features (the most frequent words) weighted by TF-IDF (Salton & Buckley, 1988). TF-IDF gives high weight to words that are frequent in an email but rare across all emails (e.g. "verify", "account", "urgent"), which are exactly the cues phishing emails use. The vectoriser is fitted on the training set only, to avoid data leakage.

**Neural network (MLP)** – implemented with scikit-learn (Pedregosa et al., 2011):

| Layer | Details |
|---|---|
| Input | <<N_FEATURES>> TF-IDF features |
| Hidden layer | 64 neurons, **ReLU** activation |
| Output layer | 1 neuron, **sigmoid** (logistic) activation → probability of phishing |

- **ReLU**, f(x) = max(0, x), is simple, fast and avoids the vanishing-gradient problem.
- **Sigmoid** squashes the output to 0–1 so it can be read as a probability; an email is "Phishing" if p ≥ 0.5.
- **Loss:** binary cross-entropy (log-loss), the standard loss for two-class problems.
- **Optimiser:** Adam (Kingma & Ba, 2015), learning rate 0.001, mini-batches of 64, L2 regularisation (alpha = 0.0001) to reduce overfitting.
- **Training:** one epoch at a time; all metrics are logged after every epoch, and **early stopping** (patience = 3 on validation loss) stops training when the validation loss stops improving and restores the best model.
- **Trainable parameters:** <<N_PARAMS>>.

**Why this model suits the data.** Email text becomes a high-dimensional, sparse vector. Bag-of-words/TF-IDF features combined with a small neural network are known to work very well on such data: the hidden layer can learn combinations of words (e.g. "click" + "verify" + "account") that indicate phishing. The model is small, trains in seconds on a normal laptop, gives fast predictions suitable for a desktop app, and – unlike large language models – is easy to explain and to audit.

## 3.3 Model result analysis (10 marks)
The dataset (<<N_TOTAL>> emails after removing empty rows and duplicates) was split into training (<<N_TRAIN>>), validation (<<N_VAL>>) and test (<<N_TEST>>) sets (70/15/15, stratified). Early stopping selected epoch <<BEST_EPOCH>> and training stopped at epoch <<STOP_EPOCH>>.

![Figure 2: Class distribution of the dataset](figures/01_class_distribution.png)

**Test-set results (unseen data):**

| Metric | Value |
|---|---|
| Accuracy | <<ACC>> |
| Precision | <<PREC>> |
| Recall | <<REC>> |
| F1-score | <<F1>> |
| AUC-ROC | <<AUC>> |

**Confusion matrix:** TN = <<TN>>, FP = <<FP>>, FN = <<FN>>, TP = <<TP>>. A false positive is a safe email wrongly flagged (annoying for users); a false negative is a phishing email that slipped through (the more dangerous error in security). Precision shows how trustworthy a "Phishing" alert is; recall shows how many real phishing emails were caught.

![Figure 3: Loss curve and validation metrics per epoch](figures/02_loss_and_metric_curves.png)

**Loss curve.** Final training loss = <<TRAIN_LOSS>> and validation loss = <<VAL_LOSS>>. <<GAP_COMMENT>>

![Figure 4: ROC curve, precision-recall curve and confusion matrix (test set)](figures/03_roc_pr_confusion.png)

**ROC and Precision–Recall curves.** The ROC curve (AUC = <<AUC>>) and the PR curve show how well the model separates the two classes across all thresholds; curves hugging the top-left (ROC) and top-right (PR) corners indicate strong separation.

**Explainability (bonus feature).** The word-impact chart below shows which words pushed one test email towards phishing, found by removing each word and measuring the drop in the model's score.

![Figure 5: Word impact for one phishing email](figures/04_xai_word_impact.png)

**Conclusion.** <<VERDICT>> Limitations: the model only analyses text (not links, headers or attachments), and the dataset is a collection of older public email corpora, so performance on modern, targeted attacks may be lower.

## 3.4 Real-world use of models in cybersecurity (7 marks)
Machine-learning models are widely applied in cybersecurity for **intrusion detection** (classifying network traffic as normal or malicious), **threat classification** (e.g. malware families, phishing, spam), **anomaly detection** (finding behaviour that deviates from a learned normal profile) and **risk assessment** (prioritising alerts and vulnerabilities) (Buczak & Guven, 2016; Chandola et al., 2009).

**Strengths.** Models learn patterns automatically from large volumes of data, process events at a speed and scale humans cannot, and can generalise to new variants of known attacks, unlike fixed signature rules. In text-based tasks such as phishing detection, models reach very high accuracy on benchmark data.

**Limitations and challenges.**
- *Data quality:* models are only as good as their labelled data. Security datasets are often outdated, imbalanced, noisy or artificially built, so benchmark scores can be over-optimistic and not reflect real deployments (Arp et al., 2022).
- *Concept drift:* attackers constantly change tactics, so the data seen in production drifts away from the training data and accuracy degrades over time. Models must be monitored and retrained regularly (Jordaney et al., 2017).
- *False positives:* because real attacks are rare compared to normal activity, even a low false-positive rate produces a very large number of false alarms (the base-rate fallacy), which causes alert fatigue and ignored warnings (Axelsson, 2000).
- *Closed-world and adversarial problems:* anomaly detection is difficult because "unusual" does not always mean "malicious", and attackers can deliberately craft inputs to evade the model (Sommer & Paxson, 2010).
- *Explainability:* security analysts need to know why something was flagged before they act; black-box models are hard to trust, which is why explanation techniques such as LIME (Ribeiro et al., 2016) – and the word-impact explanation in this project – are valuable.

**Practical effectiveness.** In practice, ML works best as one layer in a defence-in-depth strategy: combined with rules, threat intelligence and human analysts, with regular retraining, threshold tuning to balance false positives and false negatives, and realistic evaluation on up-to-date data.

### References
- Arp, D., Quiring, E., Pendlebury, F., et al. (2022). Dos and don'ts of machine learning in computer security. *31st USENIX Security Symposium*, 3971–3988.
- Axelsson, S. (2000). The base-rate fallacy and the difficulty of intrusion detection. *ACM Transactions on Information and System Security*, 3(3), 186–205.
- Buczak, A. L., & Guven, E. (2016). A survey of data mining and machine learning methods for cyber security intrusion detection. *IEEE Communications Surveys & Tutorials*, 18(2), 1153–1176.
- Chandola, V., Banerjee, A., & Kumar, V. (2009). Anomaly detection: A survey. *ACM Computing Surveys*, 41(3), Article 15.
- Jordaney, R., Sharad, K., Dash, S. K., et al. (2017). Transcend: Detecting concept drift in malware classification models. *26th USENIX Security Symposium*, 625–642.
- Kingma, D. P., & Ba, J. (2015). Adam: A method for stochastic optimization. *3rd International Conference on Learning Representations (ICLR)*.
- Pedregosa, F., Varoquaux, G., Gramfort, A., et al. (2011). Scikit-learn: Machine learning in Python. *Journal of Machine Learning Research*, 12, 2825–2830.
- Ribeiro, M. T., Singh, S., & Guestrin, C. (2016). "Why should I trust you?": Explaining the predictions of any classifier. *Proceedings of the 22nd ACM SIGKDD Conference*, 1135–1144.
- Salton, G., & Buckley, C. (1988). Term-weighting approaches in automatic text retrieval. *Information Processing & Management*, 24(5), 513–523.
- Sommer, R., & Paxson, V. (2010). Outside the closed world: On using machine learning for network intrusion detection. *IEEE Symposium on Security and Privacy*, 305–316.
