"""Builds Theory_Answers.docx (same layout as the lecturer's theory document) from Theory_Report.md.
Used by the last notebook cell. Needs: pip install python-docx"""
import re
from docx import Document
from docx.shared import Pt, Cm
from docx.enum.text import WD_ALIGN_PARAGRAPH

QUESTIONS = {
    "3.1": "Give the scenario of your model. How is this model useful in the context of cybersecurity?",
    "3.2": "Explain all relevant details of the model you used. For example, if you implemented a Convolutional Neural Network (CNN), specify the types of layers, the activation functions used, and the overall model architecture. Also explain why the chosen model is well suited to the data it was trained on.",
    "3.3": "Explain the results of your model using the metrics and graphs derived from the model's training. Is this model effective in the problem it is trying to resolve?",
    "3.4": "Evaluate the real-world use of models within the field of cybersecurity, focusing on how these models are applied to tasks such as intrusion detection, threat classification, anomaly detection, and risk assessment. Discuss their effectiveness in practical deployments, including strengths, limitations, and common challenges such as data quality, concept drift, and false positives. Use academic references.",
}


def _runs(par, text):
    """**bold**, *italic*, `code` inline formatting."""
    for part in re.split(r"(\*\*[^*]+\*\*|\*[^*]+\*|`[^`]+`)", text):
        if not part:
            continue
        if part.startswith("**"):
            par.add_run(part[2:-2]).bold = True
        elif part.startswith("*"):
            par.add_run(part[1:-1]).italic = True
        elif part.startswith("`"):
            r = par.add_run(part[1:-1]); r.font.name = "Consolas"
        else:
            par.add_run(part)


def build(md_path="Theory_Report.md", out_path="Theory_Answers.docx", students=(("", ""), ("", ""))):
    doc = Document()
    doc.styles["Normal"].font.name = "Calibri"; doc.styles["Normal"].font.size = Pt(11)
    for s in doc.sections:
        s.left_margin = s.right_margin = Cm(2.2); s.top_margin = s.bottom_margin = Cm(2)

    for name, num in students:
        p = doc.add_paragraph(); p.paragraph_format.space_after = Pt(2)
        p.add_run("Name & Surname: ").bold = True; p.add_run(name or "_" * 30)
        p.add_run("      St number: ").bold = True; p.add_run(num or "_" * 12)
    p = doc.add_paragraph(); p.paragraph_format.space_before = Pt(8)
    p.add_run("ITRI625 Project: Theory component. Model: phishing email detection (TF-IDF + neural network).").italic = True

    lines = open(md_path, encoding="utf-8").read().splitlines()
    i = 0
    while i < len(lines):
        ln = lines[i].rstrip()
        if not ln or ln.startswith("# ") or ln.startswith("**Project:**"):
            i += 1; continue
        m = re.match(r"(#{2,3}) (.*)", ln)
        if m:
            level, title = len(m.group(1)), m.group(2)
            doc.add_heading(title, level=level - 1 if level == 2 else 3)
            num = re.match(r"(3\.\d)", title)
            if level == 2 and num and num.group(1) in QUESTIONS:
                q = doc.add_paragraph(); q.add_run(QUESTIONS[num.group(1)]).italic = True
            i += 1; continue
        img = re.match(r"!\[(.*?)\]\((.*?)\)", ln)
        if img:
            try:
                doc.add_picture(img.group(2), width=Cm(10 if "01_class" in img.group(2) else 15.5)); doc.paragraphs[-1].alignment = WD_ALIGN_PARAGRAPH.CENTER
                c = doc.add_paragraph(); c.alignment = WD_ALIGN_PARAGRAPH.CENTER
                c.add_run(img.group(1)).italic = True
            except Exception as e:
                doc.add_paragraph(f"[Figure missing: {img.group(2)}. Run the notebook first.]")
            i += 1; continue
        if ln.startswith("|"):
            rows = []
            while i < len(lines) and lines[i].startswith("|"):
                cells = [c.strip() for c in lines[i].strip().strip("|").split("|")]
                if not all(re.fullmatch(r":?-+:?", c) for c in cells):
                    rows.append(cells)
                i += 1
            t = doc.add_table(rows=len(rows), cols=len(rows[0])); t.style = "Light Grid Accent 1"
            for r, row in enumerate(rows):
                for c, txt in enumerate(row):
                    cell = t.cell(r, c); cell.text = ""
                    _runs(cell.paragraphs[0], txt)
                    if r == 0:
                        for run in cell.paragraphs[0].runs: run.bold = True
            doc.add_paragraph(); continue
        if ln.startswith("- "):
            _runs(doc.add_paragraph(style="List Bullet"), ln[2:]); i += 1; continue
        _runs(doc.add_paragraph(), ln); i += 1
    doc.save(out_path)
    return out_path
