# ITRI625 – Phishing Email Detection (TF-IDF + Neural Network)

## Setup (once)
1. Download **Phishing Email Dataset** from Kaggle (file `Phishing_Email.csv`) and put it in this folder.
2. `pip install -r requirements.txt`

## Run order
1. Open `ITRI625_Phishing_Detection.ipynb` → **Kernel > Restart & Run All**. Leave ALL outputs in the notebook, then save (avoids the -10 deduction).
   This also creates `model/`, `training_log.csv`, `figures/`, `Theory_Report.md` and **`Theory_Answers.docx`** (your theory answers, in the lecturer's layout, with your real results and graphs inserted).
   Before running, type your name(s) and student number(s) in the `STUDENTS` line of the first code cell. If the last cell asks for it, run `pip install python-docx` once and re-run that cell.
2. Terminal 1: `python api.py`
3. Terminal 2: `python app.py` → a window opens → paste an email → **Check email**. (Or open http://127.0.0.1:5000 in any browser.)
   Prefer the classic Tkinter window? Run `python app_tkinter.py` instead (needs `api.py` running).

## If your CSV has 0/1 labels
The notebook handles both text labels ("Phishing Email" / "Safe Email") and numeric 0/1 labels (1 = phishing). After loading it prints two example emails per class: the "Phishing Email" ones must look like scams. If they look normal, set `FLIP_NUMERIC_LABELS = True` in the first code cell and run all again.

## Figures for the report
Every figure is also saved as a PNG in the `figures/` folder (class distribution, loss and metric curves, ROC / precision-recall / confusion matrix, XAI word impact). Paste them into the theory report, section 3.3.

## Files
| File | Purpose |
|---|---|
| `ITRI625_Phishing_Detection.ipynb` | Data split, model, logging, graphs, early stopping, XAI |
| `phish_utils.py` | Prediction + word-occlusion explainability |
| `api.py` | Flask API (`POST /predict`) |
| `app.py` | Opens the web interface (`web/index.html`) in its own app window; starts the API if needed |
| `app_tkinter.py` | Tkinter desktop app (the option named in the brief) |
| `web/index.html` | Modern web interface: marks the risky words inside the email |
| `theory_template.md` → `Theory_Report.md` → `Theory_Answers.docx` | Theory answers (auto-filled with your results and graphs) |
| `make_theory_docx.py` | Builds the Word document |

## What to submit (checklist against the brief)
| Required | Where it is |
|---|---|
| Notebook (.ipynb) with ALL outputs visible (avoids -10) | `ITRI625_Phishing_Detection.ipynb` after Restart & Run All, then Save |
| Theory document, questions 3.1 to 3.4, with names and student numbers | `Theory_Answers.docx` (made by the notebook; read it once and check the numbers) |
| Desktop app + API | `api.py`, `app.py`, `app_tkinter.py`, `web/` |
| Source control (avoids -10) | Link to your GitHub repository, with commits over several days |
| Trained model so the marker can run the app | `model/` folder |
| Evidence of results | `figures/`, `training_log.csv` |

## Version control (REQUIRED – avoid -10)
Commit often, with real messages, over several days. Suggested sequence:
```
git init && git add README.md requirements.txt && git commit -m "Project setup"
git add notebook && git commit -m "Load data and split train/val/test"
git commit -am "Add TF-IDF and MLP model"
git commit -am "Add metric logging and early stopping"
git commit -am "Add evaluation graphs"
git add phish_utils.py api.py && git commit -m "Add XAI and Flask API"
git add app.py app_tkinter.py web && git commit -m "Add desktop apps"
git add Theory_Report.md && git commit -m "Add theory report"
git remote add origin <your-repo-url> && git push -u origin main
```
(Use a `.gitignore` for `model/` only if the repo size is a problem; otherwise commit it so the app runs after cloning.)

## 5-minute demo script
1. **Problem:** phishing emails → classify Phishing/Safe.
2. **Data:** Kaggle dataset, split 70/15/15 (train/val/test).
3. **Model:** TF-IDF turns text into numbers → small neural net (64 ReLU neurons → sigmoid).
4. **Training:** show per-epoch log; early stopping (patience 3) stops it automatically.
5. **Results:** show loss curve, ROC, PR, confusion matrix, metrics table.
6. **App:** run `api.py` + `app.py` (or `app_tkinter.py`), paste a phishing and a safe email; point out the "Why?" words (XAI).
