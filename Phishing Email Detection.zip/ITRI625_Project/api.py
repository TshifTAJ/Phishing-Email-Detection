"""Flask API + web interface.  Run:  python api.py   then open http://127.0.0.1:5000
(or just run  python app.py  which starts everything and opens the window)."""
from pathlib import Path
import joblib
from flask import Flask, request, jsonify, send_from_directory
from phish_utils import explain

HERE = Path(__file__).parent
app = Flask(__name__)
model = joblib.load(HERE / "model" / "model.joblib")
vec = joblib.load(HERE / "model" / "vectorizer.joblib")


@app.route("/")
def home():
    return send_from_directory(HERE / "web", "index.html")


@app.route("/health")
def health():
    return jsonify({"status": "ok"})


@app.route("/predict", methods=["POST"])
def predict():
    text = (request.get_json(silent=True) or {}).get("text", "").strip()
    if not text:
        return jsonify({"error": "No text supplied"}), 400
    k = min(max(request.args.get("top_k", 5, type=int), 1), 20)
    prob, top = explain(model, vec, text, top_k=k)
    return jsonify({
        "label": "Phishing" if prob >= 0.5 else "Safe",
        "phishing_probability": round(prob, 4),
        "top_words": [{"word": w, "impact": round(s, 4)} for w, s in top],
    })


if __name__ == "__main__":
    app.run(port=5000)
